package frc.robot;

public class Constants {
    public static final double kEpsilon = 0.0001;
    public static final double kPi = 3.141592;

    public static final double kMetersPerFoot = 0.3048;
    public static final double kFeetPerMeter = 3.28084;
    
    public static final double kKilogramsPerPound = 0.453592;
    public static final double kPoundsPerKilogram = 2.20462;

    public static final double kSRXUnitsPerRotation = 4096.0;
    public static final double kDegreesPerRotation = 360.0;
}
