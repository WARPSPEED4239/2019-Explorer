package frc.robot.commands;

import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;

public class ElevatorSetPosition extends Command {
  private final double kMaxOffsetChangeInInchesPerSecond = 12.0;
  private double mOffset;

  private final double mTargetPositionInInches;

  public ElevatorSetPosition(double targetPositionInInches) {
    requires(Robot.mElevator);
    mTargetPositionInInches = targetPositionInInches;
    mOffset = 0.0;
  }

  @Override
  protected void initialize() {
  }

  @Override
  protected void execute() {
    double joystickValue = -Robot.mOI.getController().getY(Hand.kLeft);
    if (Math.abs(joystickValue) > 0.1) {
      mOffset += joystickValue * kMaxOffsetChangeInInchesPerSecond * 0.02;
    }

    SmartDashboard.putNumber("Elevator Target Position", mTargetPositionInInches + mOffset);

    if (Robot.mOI.getController().getBumper(Hand.kLeft)) {
      Robot.mElevator.setPositionInInches(mTargetPositionInInches + mOffset);
    }
    else {
      Robot.mElevator.setPercentOutput(0.0);
    }
  }

  @Override
  protected boolean isFinished() {
    return false;
  }

  @Override
  protected void end() {
  }

  @Override
  protected void interrupted() {
  }
}
