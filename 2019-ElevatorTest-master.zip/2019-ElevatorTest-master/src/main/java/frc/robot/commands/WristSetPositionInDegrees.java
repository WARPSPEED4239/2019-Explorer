package frc.robot.commands;

import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;

public class WristSetPositionInDegrees extends Command {
  private final double kMaxOffsetChangeInDegreesPerSecond = 10;
  private double mOffset;

  private final double mTargetPositionInDegrees;

  public WristSetPositionInDegrees(double positionInDegrees) {
    requires(Robot.mWrist);
    mTargetPositionInDegrees = positionInDegrees;
    mOffset = 0.0;
  }

  @Override
  protected void initialize() {
  }

  @Override
  protected void execute() {
    double joystickValue = -Robot.mOI.getController().getY(Hand.kRight);
    if (Math.abs(joystickValue) > 0.1) {
      mOffset += joystickValue * kMaxOffsetChangeInDegreesPerSecond * 0.02;
    }

    SmartDashboard.putNumber("Wrist Target Position", mTargetPositionInDegrees + mOffset);

    if (Robot.mOI.getController().getBumper(Hand.kRight)) {
      Robot.mWrist.setPositionInDegrees(mTargetPositionInDegrees + mOffset);
    }
    else {
      Robot.mWrist.setPercentOutput(0.0);
    }
  }

  @Override
  protected boolean isFinished() {
    return false;
  }

  @Override
  protected void end() {
  }

  @Override
  protected void interrupted() {
  }
}
