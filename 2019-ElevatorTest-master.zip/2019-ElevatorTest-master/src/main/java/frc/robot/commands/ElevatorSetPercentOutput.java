package frc.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import frc.robot.Robot;

public class ElevatorSetPercentOutput extends Command {
  private final double mOutput;
  private final String mLogFilename;
  private final boolean mLogKinematics;
  private final double mTimeToRampInSeconds;

  public ElevatorSetPercentOutput(double output) {
    this(output, false, "");
  }

  public ElevatorSetPercentOutput(double output, boolean logKinematics, String logFilename) {
    this(output, logKinematics, logFilename, Robot.mElevator.getDefaultRamp());
  }

  public ElevatorSetPercentOutput(double output, boolean logKinematics, String logFilename, double timeToRampInSeconds) {
    requires(Robot.mElevator);
    mOutput = output;
    mLogKinematics = logKinematics;
    mLogFilename = logFilename;
    mTimeToRampInSeconds = timeToRampInSeconds;
  }

  @Override
  protected void initialize() {
    Robot.mElevator.configRamp(mTimeToRampInSeconds);
  }

  @Override
  protected void execute() {
    Robot.mElevator.setPercentOutput(mOutput);
    if (mLogKinematics) {
      Robot.mElevator.logKinematics();
    }
  }

  @Override
  protected boolean isFinished() {
    return false;
  }

  @Override
  protected void end() {
    if (mLogKinematics) {
      System.out.println("Flusing Elevator Kinematics:");
      Robot.mElevator.writeKinematicsCSV(mLogFilename);
      Robot.mElevator.configRamp(Robot.mWrist.getDefaultRamp());
    }
  }

  @Override
  protected void interrupted() {
    end();
  }
}
