package frc.robot.commands;

import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.command.Command;
import frc.robot.Robot;

public class DrivetrainDriveWithJoystick extends Command {
  public DrivetrainDriveWithJoystick() {
    requires(Robot.mDrivetrain);
  }

  @Override
  protected void initialize() {
  }

  @Override
  protected void execute() {
    double move = -Robot.mOI.getController().getTriggerAxis(Hand.kRight) + Robot.mOI.getController().getTriggerAxis(Hand.kLeft);
    double rotate = -Robot.mOI.getController().getX(Hand.kLeft);
    Robot.mDrivetrain.arcadeDrive(move, rotate);
  }

  @Override
  protected boolean isFinished() {
    return false;
  }

  @Override
  protected void end() {
  }

  @Override
  protected void interrupted() {
  }
}
