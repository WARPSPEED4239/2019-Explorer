package frc.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import frc.robot.Robot;

public class WristSetPercentOutput extends Command {
  private final double mOutput;
  private final boolean mLogKinematics;
  private final String mLogFilename;
  private final double mTimeToRampInSeconds;

  public WristSetPercentOutput(double output) {
    this(output, false, "");
  }

  public WristSetPercentOutput(double output, boolean logKinematics, String logFilename) {
    this(output, logKinematics, logFilename, Robot.mWrist.getDefaultRamp());
  }

  public WristSetPercentOutput(double output, boolean logKinematics, String logFilename, double timeToRampInSeconds) {
    requires(Robot.mWrist);
    mOutput = output;
    mLogKinematics = logKinematics;
    mLogFilename = logFilename;
    mTimeToRampInSeconds = timeToRampInSeconds;
  }

  @Override
  protected void initialize() {
    Robot.mWrist.configRamp(mTimeToRampInSeconds);
  }

  @Override
  protected void execute() {
    Robot.mWrist.setPercentOutput(mOutput);
    if (mLogKinematics) {
      Robot.mWrist.logKinematics();
    }
  }

  @Override
  protected boolean isFinished() {
    return false;
  }

  @Override
  protected void end() {
    if (mLogKinematics) {
      System.out.println("Wrist Kinematics");
      Robot.mWrist.writeKinematicsCSV(mLogFilename);
      Robot.mWrist.configRamp(Robot.mWrist.getDefaultRamp());
    }
  }

  @Override
  protected void interrupted() {
    end();
  }
}
