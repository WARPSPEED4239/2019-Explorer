package frc.robot.tools;

import frc.robot.Constants;

public class DerivativeTracker {

    private double mLastTime;
    private double mLastValue;
    private double mDerivative;

    public DerivativeTracker() {
        mLastTime = 0.0;
        mLastValue = 0.0;
    }

    public double getDerivative() {
        return mDerivative;
    }

    public void update(double currentValue, double currentTime) {
        if (Math.abs(mLastTime) > Constants.kEpsilon) {
            double dt = currentTime - mLastTime;
            mDerivative = (currentValue - mLastValue) / dt;
        }
        mLastTime = currentTime;
        mLastValue = currentValue;
    }

}
