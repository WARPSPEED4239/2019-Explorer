package frc.robot.tools;

public class CSVWriter {

    private final int kNumberOfLabels;
    private final StringBuilder mLabelBuilder;
    private final StringBuilder mDataBuilder;

    public CSVWriter(String... labels) {
        kNumberOfLabels = labels.length;
        mLabelBuilder = new StringBuilder();
        mDataBuilder = new StringBuilder();

        if (kNumberOfLabels < 1) {
            System.err.println("CSVWriter CSVWriter(): CSV must have at least 1 label.");
            return;
        }

        boolean first = true;
        for (String label : labels) {
            if (first) {
                first = false;
            }
            else {
                mLabelBuilder.append(", ");
            }
            mLabelBuilder.append(label);
        }
        mLabelBuilder.append("\n");
    }

    public void writeData(Object... data) {
        if (data.length != kNumberOfLabels || kNumberOfLabels < 1) {
            System.err.println("CSVWriter writeData(): Data points do not match labels");
            return;
        }

        boolean first = true;
        for (Object d : data) {
            if (first) {
                first = false;
            }
            else {
                mDataBuilder.append(", ");
            }
            mDataBuilder.append(d.toString());
        }
        mDataBuilder.append("\n");
    }

    public String getData() {
        return mLabelBuilder.toString() + mDataBuilder.toString();
    }

    public void clearData() {
        mDataBuilder.setLength(0);
    }

}
