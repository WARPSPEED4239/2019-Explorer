package frc.robot.tools;

import frc.robot.Constants;

public class UnitConversion {
    public static double convertMetersToFeet(double meters) {
        return meters * Constants.kFeetPerMeter;
    }

    public static double convertFeetToMeters(double feet) {
        return feet * Constants.kMetersPerFoot;
    }

    public static double convertPoundsToKilograms(double pounds) {
        return pounds * Constants.kKilogramsPerPound;
    }

    public static double convertKilogramsToPounds(double kilograms) {
        return kilograms * Constants.kPoundsPerKilogram;
    }

    public static double convertRevolutionsPerMinuteToRadiansPerSecond(double rpm) {
        return rpm * 2.0 * Constants.kPi / 60;
    }

    public static double convertSRXUnitsToRotations(double units) {
        return units / Constants.kSRXUnitsPerRotation;
    }

    public static double convertRotationsToSRXUnits(double rotations) {
        return rotations * Constants.kSRXUnitsPerRotation;
    }

    public static double convertRotationsToInches(double rotations, double pulleyDiameter) {
        return rotations * Constants.kPi * pulleyDiameter;
    }

    public static double convertPositionInInchesToRotations(double positionInInches, double pulleyDiameter) {
        return positionInInches / (pulleyDiameter * Constants.kPi);
    }

    public static double convertSRXUnitsToDegrees(double units) {
        return units / Constants.kSRXUnitsPerRotation * Constants.kDegreesPerRotation;
    }

    public static double convertPositionInDegreesToSRXUnits(double positionInDegrees) {
        return positionInDegrees / Constants.kDegreesPerRotation * Constants.kSRXUnitsPerRotation;
    }
}
