package frc.robot.subsystems;

import java.io.File;
import java.io.PrintWriter;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.DemandType;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.NeutralMode;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Constants;
import frc.robot.RobotMap;
import frc.robot.commands.ElevatorSetPercentOutput;
import frc.robot.tools.CSVWriter;
import frc.robot.tools.DerivativeTracker;
import frc.robot.tools.UnitConversion;

public class Elevator extends Subsystem {

  private final WPI_TalonSRX mMaster;
  private final WPI_TalonSRX mSlave;

  private final DigitalInput mBottomLimitSwitch;
  private final DigitalInput mTopLimitSwitchOne;
  private final DigitalInput mTopLimitSwitchTwo;

  private final DerivativeTracker mAccelerationTracker;
  private final DerivativeTracker mActiveTrajectoryAccelerationTracker;
  private final CSVWriter mKinematicsLogger;

  private final int kPeakCurrentLimitInAmps = 45;
  private final int kContinuousCurrentLimitInAmps = 40;
  private final int kCruiseVelocityInSRXUnits = 2000;
  private final int kMaxAccelerationInSRXUnits = 2000;
  private final int kSRXSlotIdx = 0;
  private final int kSRXPidIdx = 0;
  private final double kPulleyDiameterInInches = 1.65;

  private static final String kErrorMessageKey = "Elevator Error";

  private static Elevator sInstance;
  public static Elevator getInstance() {
    if (sInstance == null) {
      sInstance = new Elevator(
        new WPI_TalonSRX(RobotMap.elevatorMotorOne),
        new WPI_TalonSRX(RobotMap.elevatorMotorTwo),
        new DigitalInput(RobotMap.liftBottomLimitSwitch),
        new DigitalInput(RobotMap.liftTop2To1LimitSwitch),
        new DigitalInput(RobotMap.liftTop3To2LimitSwitch)
      ); 
    }

    return sInstance;
  }

  public Elevator(WPI_TalonSRX master, WPI_TalonSRX slave, DigitalInput bottomLimitSwitch, DigitalInput topLimitSwitchOne, DigitalInput topLimitSwitchTwo) {
    mMaster = master;
    mSlave = slave;
    mBottomLimitSwitch = bottomLimitSwitch;
    mTopLimitSwitchOne = topLimitSwitchOne;
    mTopLimitSwitchTwo = topLimitSwitchTwo;

    mAccelerationTracker = new DerivativeTracker();
    mActiveTrajectoryAccelerationTracker = new DerivativeTracker();
    mKinematicsLogger = new CSVWriter(
      "Time (s)", 
      "Position (deg)", 
      "Velocity (deg/s)", 
      "Acceleration (deg/s^2)", 
      "Trajectory Position (deg)",
      "Trajectory Velocity (deg/s)",
      "Trajectory Acceleration (deg/s^2)",
      "Voltage (Volts)", 
      "Percent Output ([0-1])"
    );

    configureTalons();
  }

  @Override
  public void initDefaultCommand() {
    setDefaultCommand(new ElevatorSetPercentOutput(0.0));
  }

  public void setPercentOutput(double output) {
    String errorMessageValue = "None";
    if (output > 1.0) {
      errorMessageValue = "Output " + output + " is greater than 1.0";
      output = 1.0;
    }
    else if (output < -1.0) {
      errorMessageValue = "Output " + output + " is less than -1.0";
      output = -1.0;
    }

    if (output > Constants.kEpsilon && getTopLimit()) {
      errorMessageValue = "Top Limit Switch tripped and output is " + output;
      output = 0.0;
    }
    else if (output < -Constants.kEpsilon && getBottomLimit()) {
      errorMessageValue = "Bottom Limit Switch tripped and output is " + output;
      output = 0.0;
    }

    SmartDashboard.putString(kErrorMessageKey, errorMessageValue);
    SmartDashboard.putNumber("Elevator Percent Output", output);
    mMaster.set(ControlMode.PercentOutput, output);
  }

  public void setPositionInInches(double positionInInches) {
    String errorMessageValue = "None";
    double motorVoltageInVolts = mMaster.getMotorOutputVoltage();

    if (getTopLimit() && motorVoltageInVolts > Constants.kEpsilon) {
      errorMessageValue = "Top Limit Switch tripped and voltage is " + motorVoltageInVolts;
      mMaster.set(ControlMode.PercentOutput, 0.0);
    }
    else if (getBottomLimit() && motorVoltageInVolts < -Constants.kEpsilon) {
      errorMessageValue = "Bottom Limit Switch tripped and voltage is " + motorVoltageInVolts;
      mMaster.set(ControlMode.PercentOutput, 0.0);
    }
    else {
      double positionInRotations = UnitConversion.convertPositionInInchesToRotations(positionInInches, kPulleyDiameterInInches);
      double positionInSRXUnits = UnitConversion.convertRotationsToSRXUnits(positionInRotations);

      double feedforward = 0.0;
      mMaster.set(ControlMode.MotionMagic, positionInSRXUnits, DemandType.ArbitraryFeedForward, feedforward);
    }

    SmartDashboard.putString(kErrorMessageKey, errorMessageValue);
    SmartDashboard.putNumberArray("Elevator Position Info", new double[]{ getPositionInInches(), getActiveTrajectoryPositionInInches() });
    SmartDashboard.putNumberArray("Elevator Velocity Info", new double[]{ getVelocityInInchesPerSecond(), getActiveTrajectoryVelocityInInchesPerSecond() });
    SmartDashboard.putNumberArray("Elevator Acceleration Info", new double[]{ getAccelerationInIncesPerSecondSquared(), getActiveTrajectoryAccelerationInInchesPerSecondSquared() });
  }

  public void resetEncoder() {
    mMaster.setSelectedSensorPosition(0);
  }

  public double getPositionInInches() {
    double positionInSRXUnits = mMaster.getSelectedSensorPosition();
    double positionInRotations = UnitConversion.convertSRXUnitsToRotations(positionInSRXUnits);
    return UnitConversion.convertRotationsToInches(positionInRotations, kPulleyDiameterInInches);
  }

  public double getVelocityInInchesPerSecond() {
    double velocityInSRXUnitsPerSec = mMaster.getSelectedSensorVelocity() * 10;
    double velocityInRotationsPerSec = UnitConversion.convertSRXUnitsToRotations(velocityInSRXUnitsPerSec);
    return UnitConversion.convertRotationsToInches(velocityInRotationsPerSec, kPulleyDiameterInInches);
  }

  public double getAccelerationInIncesPerSecondSquared() {
    return mAccelerationTracker.getDerivative();
  }

  public double getActiveTrajectoryPositionInInches() {
    double positionInSRXUnits = mMaster.getActiveTrajectoryPosition();
    double positionInRotations = UnitConversion.convertSRXUnitsToRotations(positionInSRXUnits);
    return UnitConversion.convertRotationsToInches(positionInRotations, kPulleyDiameterInInches); 
  }

  public double getActiveTrajectoryVelocityInInchesPerSecond() {
    double velocityInSRXUnitsPerSec = mMaster.getActiveTrajectoryVelocity() * 10;
    double velocityInRotationsPerSec = UnitConversion.convertSRXUnitsToRotations(velocityInSRXUnitsPerSec);
    return UnitConversion.convertRotationsToInches(velocityInRotationsPerSec, kPulleyDiameterInInches);
  }

  public double getActiveTrajectoryAccelerationInInchesPerSecondSquared() {
    return mActiveTrajectoryAccelerationTracker.getDerivative();
  }

  public boolean getTopLimit() {
    return !mTopLimitSwitchOne.get() && !mTopLimitSwitchTwo.get();
  }

  public boolean getBottomLimit() {
    return !mBottomLimitSwitch.get();
  }

  private double mLastUpdateTime;
  public void updateKinematics(double currentTime) {
    mLastUpdateTime = currentTime;
    mAccelerationTracker.update(getVelocityInInchesPerSecond(), currentTime);
    mActiveTrajectoryAccelerationTracker.update(getActiveTrajectoryVelocityInInchesPerSecond(), currentTime);
  }

  public void logKinematics() {
    mKinematicsLogger.writeData(
      mLastUpdateTime,
      getPositionInInches(),
      getVelocityInInchesPerSecond(),
      getAccelerationInIncesPerSecondSquared(),
      getActiveTrajectoryPositionInInches(),
      getActiveTrajectoryVelocityInInchesPerSecond(),
      getActiveTrajectoryAccelerationInInchesPerSecondSquared(),
      mMaster.getMotorOutputVoltage(),
      mMaster.getMotorOutputPercent()
    );
  }

  public void writeKinematicsCSV(String filename) {
    String csv = mKinematicsLogger.getData();
    mKinematicsLogger.clearData();

    File file = new File("/home/lvuser/elevatortests/" + filename);
    try {
      PrintWriter out = new PrintWriter(file);
      out.println(csv);
      out.close();
    } catch (Exception e) {
      System.out.println(e);
    }
  }

  public void configRamp(double secondsFromNeutralToFull) {
    mMaster.configOpenloopRamp(secondsFromNeutralToFull);
    mMaster.configClosedloopRamp(secondsFromNeutralToFull);
  }

  public double getDefaultRamp() {
    return 0.1;
  }

  private void configureTalons() {
    mMaster.configFactoryDefault();
    mSlave.configFactoryDefault();

    mSlave.follow(mMaster);

    mMaster.configSelectedFeedbackSensor(FeedbackDevice.CTRE_MagEncoder_Relative);

    mMaster.setNeutralMode(NeutralMode.Brake);
    mMaster.configPeakCurrentLimit(kPeakCurrentLimitInAmps);
    mMaster.configContinuousCurrentLimit(kContinuousCurrentLimitInAmps);

    mMaster.setInverted(false);
    mMaster.setSensorPhase(true);

    mMaster.configVoltageCompSaturation(12.0);
    configRamp(getDefaultRamp());

    mMaster.configNominalOutputForward(0.0);
    mMaster.configNominalOutputReverse(0.0);
    mMaster.configPeakOutputForward(1.0);
    mMaster.configPeakOutputReverse(-1.0);

    mMaster.selectProfileSlot(kSRXSlotIdx, kSRXPidIdx);
    mMaster.config_kF(kSRXSlotIdx, 1023.0 / 4000.0);
    mMaster.config_kP(kSRXSlotIdx, 0.1);
    mMaster.config_kI(kSRXSlotIdx, 0.0);
    mMaster.config_kD(kSRXSlotIdx, 0.0);

    mMaster.configMotionCruiseVelocity(kCruiseVelocityInSRXUnits);
    mMaster.configMotionAcceleration(kMaxAccelerationInSRXUnits);
  }

}
