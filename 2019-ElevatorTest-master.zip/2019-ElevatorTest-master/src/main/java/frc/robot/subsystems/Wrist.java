package frc.robot.subsystems;

import java.io.File;
import java.io.PrintWriter;

import com.ctre.phoenix.CANifier;
import com.ctre.phoenix.CANifier.GeneralPin;
import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.DemandType;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.NeutralMode;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Constants;
import frc.robot.RobotMap;
import frc.robot.commands.WristSetPercentOutput;
import frc.robot.tools.CSVWriter;
import frc.robot.tools.DerivativeTracker;
import frc.robot.tools.UnitConversion;

public class Wrist extends Subsystem {
  public final WPI_TalonSRX mMotor;
  public final CANifier mCanifier;

  private final int kPeakCurrentLimitInAmps = 45;
  private final int kContinuousCurrentLimitInAmps = 40;
  private final int kCruiseVelocityInSRXUnits = 275;
  private final int kMaxAccelerationInSRXUnits = 275;
  private final int kSRXSlotIdx = 0;
  private final int kSRXPidIdx = 0;

  private final DerivativeTracker mAccelerationTracker;
  private final DerivativeTracker mActiveTrajectoryAccelerationTracker;
  private final CSVWriter mKinematicsLogger;

  private static final String kErrorMessageKey = "Wrist Error";

  private static Wrist sInstance;
  public static Wrist getInstance() {
    if (sInstance == null) {
      sInstance = new Wrist(
        new WPI_TalonSRX(RobotMap.wristMotor),
        new CANifier(RobotMap.canifier)
      );
    }    

    return sInstance;
  }

  public Wrist(WPI_TalonSRX motor, CANifier canifier) {
    mMotor = motor;
    mCanifier = canifier;

    mAccelerationTracker = new DerivativeTracker();
    mActiveTrajectoryAccelerationTracker = new DerivativeTracker();
    mKinematicsLogger = new CSVWriter(
      "Time (s)", 
      "Position (deg)", 
      "Velocity (deg/s)", 
      "Acceleration (deg/s^2)", 
      "Trajectory Position (deg)",
      "Trajectory Velocity (deg/s)",
      "Trajectory Acceleration (deg/s^2)",
      "Voltage (Volts)", 
      "Percent Output ([0-1])"
    );

    configureTalon();
  }

  @Override
  public void initDefaultCommand() {
    setDefaultCommand(new WristSetPercentOutput(0.0));
  }

  public void setPercentOutput(double output) {
    String errorMessageValue = "None";
    if (output > 1.0) {
      errorMessageValue = "Output " + output + " is greater than 1.0";
      output = 1.0;
    }
    else if (output < -1.0) {
      errorMessageValue = "Output " + output + " is less than -1.0";
      output = -1.0;
    }

    if (output > Constants.kEpsilon && getTopLimit()) {
      errorMessageValue = "Top Limit Switch tripped and output is " + output;
      output = 0.0;
    }
    else if (output < -Constants.kEpsilon && getBottomLimit()) {
      errorMessageValue = "Bottom Limit Switch tripped and output is " + output;
      output = 0.0;
    }

    SmartDashboard.putString(kErrorMessageKey, errorMessageValue);
    SmartDashboard.putNumber("Wrist Percent Output", output);
    mMotor.set(ControlMode.PercentOutput, output);
  }

  public void setPositionInDegrees(double positionInDegrees) {
    String errorMessageValue = "None";
    double motorVoltageInVolts = mMotor.getMotorOutputVoltage();

    if (getTopLimit() && motorVoltageInVolts > Constants.kEpsilon) {
      errorMessageValue = "Top Limit Switch tripped and voltage is " + motorVoltageInVolts;
      mMotor.set(ControlMode.PercentOutput, 0.0);
    }
    else if (getBottomLimit() && motorVoltageInVolts < -Constants.kEpsilon) {
      errorMessageValue = "Bottom Limit Switch tripped and voltage is " + motorVoltageInVolts;
      mMotor.set(ControlMode.PercentOutput, 0.0);
    }
    else {
      double wristGravityComponent = Math.cos(Math.toRadians(getPositionInDegrees())) * 0.1;
      
      
      double drivetrainAcceleration = 
        (Drivetrain.getInstance().getLeftAccelerationInInchesPerSecondSquared() + 
         Drivetrain.getInstance().getRightAccelerationInInchesPerSecondSquared()) / 2;
      SmartDashboard.putNumber("Drivetrain Acceleration (in/s^2)", drivetrainAcceleration);

      final double kDrive = -0.5;
      final double kMaxAccelInInchesPerSecondSquared = 300.0;
      double drivetrainComponent = kDrive * drivetrainAcceleration / kMaxAccelInInchesPerSecondSquared; 

      double feedforward = wristGravityComponent + drivetrainComponent;

      double positionInSRXUnits = UnitConversion.convertPositionInDegreesToSRXUnits(positionInDegrees);
      mMotor.set(ControlMode.MotionMagic, positionInSRXUnits, DemandType.ArbitraryFeedForward, feedforward);
    }

    SmartDashboard.putString(kErrorMessageKey, errorMessageValue);
    SmartDashboard.putNumberArray("Wrist Position Info", new double[]{ getPositionInDegrees(), getActiveTrajectoryPositionInDegrees() });
    SmartDashboard.putNumberArray("Wrist Velocity Info", new double[]{ getVelocityInDegreesPerSecond(), getActiveTrajectoryVelocityInDegreesPerSecond() }); 
  }

  public void resetEncoder() {
    mMotor.setSelectedSensorPosition(0);
  }

  public double getPositionInDegrees() {
    double positionInSRXUnits = mMotor.getSelectedSensorPosition();
    return UnitConversion.convertSRXUnitsToDegrees(positionInSRXUnits);
  }

  public double getActiveTrajectoryPositionInDegrees() {
    double positionInSRXUnits = mMotor.getActiveTrajectoryPosition();
    return UnitConversion.convertSRXUnitsToDegrees(positionInSRXUnits);
  }

  public double getVelocityInDegreesPerSecond() {
    double velocityInSrxUnitsPerSec = mMotor.getSelectedSensorVelocity() * 10;
    return UnitConversion.convertSRXUnitsToDegrees(velocityInSrxUnitsPerSec);
  }

  public double getActiveTrajectoryVelocityInDegreesPerSecond() {
    double velocityInSrxUnitsPerSec = mMotor.getActiveTrajectoryVelocity() * 10;
    return UnitConversion.convertSRXUnitsToDegrees(velocityInSrxUnitsPerSec);
  }

  public double getAccelerationInDegreesPerSecondSquared() {
    return mAccelerationTracker.getDerivative();
  }

  public double getActiveTrajectoryAccelerationInDegreesPerSecondSquared() {
    return mActiveTrajectoryAccelerationTracker.getDerivative();
  }

  public boolean getTopLimit() {
    return !mCanifier.getGeneralInput(GeneralPin.LIMF);
  }

  public boolean getBottomLimit() {
    return !mCanifier.getGeneralInput(GeneralPin.LIMR);
  }

  private double mLastUpdateTime;
  public void updateKinematics(double currentTime) {
    mLastUpdateTime = currentTime;
    mAccelerationTracker.update(getVelocityInDegreesPerSecond(), currentTime);
    mActiveTrajectoryAccelerationTracker.update(getActiveTrajectoryVelocityInDegreesPerSecond(), currentTime);
  }

  public void logKinematics() {
    mKinematicsLogger.writeData(
      mLastUpdateTime,
      getPositionInDegrees(),
      getVelocityInDegreesPerSecond(),
      getAccelerationInDegreesPerSecondSquared(),
      getActiveTrajectoryPositionInDegrees(),
      getActiveTrajectoryVelocityInDegreesPerSecond(),
      getActiveTrajectoryAccelerationInDegreesPerSecondSquared(),
      mMotor.getMotorOutputVoltage(),
      mMotor.getMotorOutputPercent()
    );
  }

  public void writeKinematicsCSV(String filename) {
    String csv = mKinematicsLogger.getData();
    mKinematicsLogger.clearData();

    File file = new File("/home/lvuser/elevatortests/" + filename);
    try {
      PrintWriter out = new PrintWriter(file);
      out.println(csv);
      out.close();
    } catch (Exception e) {
      System.out.println(e);
    }
  }

  public void configRamp(double secondsFromNeutralToFull) {
    mMotor.configOpenloopRamp(secondsFromNeutralToFull);
    mMotor.configClosedloopRamp(secondsFromNeutralToFull);
  }

  public double getDefaultRamp() {
    return 0.001;
  }
  
  private void configureTalon() {
    mMotor.configFactoryDefault();

    mMotor.configSelectedFeedbackSensor(FeedbackDevice.CTRE_MagEncoder_Absolute);

    mMotor.setNeutralMode(NeutralMode.Brake);
    mMotor.configPeakCurrentLimit(kPeakCurrentLimitInAmps);
    mMotor.configContinuousCurrentLimit(kContinuousCurrentLimitInAmps);

    mMotor.setInverted(true);
    mMotor.setSensorPhase(false);

    mMotor.configVoltageCompSaturation(12.0);
    configRamp(getDefaultRamp());

    mMotor.configNominalOutputForward(0.0);
    mMotor.configNominalOutputReverse(0.0);
    mMotor.configPeakOutputForward(1.0);
    mMotor.configPeakOutputReverse(-1.0);

    mMotor.selectProfileSlot(kSRXSlotIdx, kSRXPidIdx);
    mMotor.config_kF(kSRXSlotIdx, 1023.0 / 550.0);
    mMotor.config_kP(kSRXSlotIdx, 4.0);
    mMotor.config_kI(kSRXSlotIdx, 0.0);
    mMotor.config_kD(kSRXSlotIdx, 40.0);

    mMotor.configMotionCruiseVelocity(kCruiseVelocityInSRXUnits);
    mMotor.configMotionAcceleration(kMaxAccelerationInSRXUnits);
  }

}
