/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import com.revrobotics.CANEncoder;
import com.revrobotics.CANSparkMax;
import com.revrobotics.CANSparkMaxLowLevel;

import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.RobotMap;
import frc.robot.commands.DrivetrainDriveWithJoystick;
import frc.robot.tools.DerivativeTracker;
import frc.robot.tools.UnitConversion;

public class Drivetrain extends Subsystem {

  private final CANSparkMax mLeftMaster;
  private final CANSparkMax mLeftSlaveOne;
  private final CANSparkMax mLeftSlaveTwo;
  private final CANSparkMax mRightMaster;
  private final CANSparkMax mRightSlaveOne;
  private final CANSparkMax mRightSlaveTwo;

  private DifferentialDrive mDrive;

  private final CANEncoder mLeftEncoder;
  private final CANEncoder mRightEncoder;

  private final double kGearRatio = 7.08;
  private final double kWheelDiameter = 6;

  private DerivativeTracker mLeftAccelerationTracker;
  private DerivativeTracker mRightAccelerationTracker;

  private static Drivetrain sInstance;
  public static Drivetrain getInstance() {
    if (sInstance == null) {
      sInstance = new Drivetrain(
        new CANSparkMax(RobotMap.drivetrainLeftOne, CANSparkMaxLowLevel.MotorType.kBrushless),
        new CANSparkMax(RobotMap.drivetrainLeftTwo, CANSparkMaxLowLevel.MotorType.kBrushless),
        new CANSparkMax(RobotMap.drivetrainLeftThree, CANSparkMaxLowLevel.MotorType.kBrushless),
        new CANSparkMax(RobotMap.drivetrainRightFour, CANSparkMaxLowLevel.MotorType.kBrushless),
        new CANSparkMax(RobotMap.drivetrainRightFive, CANSparkMaxLowLevel.MotorType.kBrushless),
        new CANSparkMax(RobotMap.drivetrainRightSix, CANSparkMaxLowLevel.MotorType.kBrushless)
      );
    }

    return sInstance;
  }

  public Drivetrain(CANSparkMax leftMaster, CANSparkMax leftSlaveOne, CANSparkMax leftSlaveTwo,
                    CANSparkMax rightMaster, CANSparkMax rightSlaveOne, CANSparkMax rightSlaveTwo) {
    mLeftMaster = leftMaster;
    mLeftSlaveOne = leftSlaveOne;
    mLeftSlaveTwo = leftSlaveTwo;
    mRightMaster = rightMaster;
    mRightSlaveOne = rightSlaveOne;
    mRightSlaveTwo = rightSlaveTwo;
    mDrive = new DifferentialDrive(mLeftMaster, mRightMaster);

    mLeftEncoder = new CANEncoder(mLeftMaster);
    mRightEncoder = new CANEncoder((mRightMaster));

    mLeftAccelerationTracker = new DerivativeTracker();
    mRightAccelerationTracker = new DerivativeTracker();
  }

  @Override
  public void initDefaultCommand() {
    setDefaultCommand(new DrivetrainDriveWithJoystick());
  }

  public void arcadeDrive(double move, double rotate) {
    final double MIN_MOVE_THRESHOLD = 0.05;
    final double MIN_ROTATE_THRESHOLD = 0.05;

    if (Math.abs(move) < MIN_MOVE_THRESHOLD)
      move = 0.0;

    if (Math.abs(rotate) < MIN_ROTATE_THRESHOLD)
      rotate = 0.0;
    
    mDrive.arcadeDrive(move, rotate);

    SmartDashboard.putNumber("Drivetrain Left Position (in)", getLeftPositionInInches());
    SmartDashboard.putNumber("Drivetrain Left Velocity (in/s)", getLeftVelocityInInchesPerSecond());
    SmartDashboard.putNumber("Drivetrain Left Acceleration (in/s^2)", getLeftAccelerationInInchesPerSecondSquared());
    SmartDashboard.putNumber("Drivetrain Right Position (in)", getRightPositionInInches());
    SmartDashboard.putNumber("Drivetrain Right Velocity (in/s)", getRightVelocityInInchesPerSecond());
    SmartDashboard.putNumber("Drivetrain Right Acceleration (in/s^2)", getRightAccelerationInInchesPerSecondSquared());
  }

  public void resetEncoder() {
    mLeftEncoder.setPosition(0.0);
    mRightEncoder.setPosition(0.0);
  }

  public double getLeftPositionInInches() {
    double leftPositionInRotations = -mLeftEncoder.getPosition();
    return UnitConversion.convertRotationsToInches(leftPositionInRotations / kGearRatio, kWheelDiameter);
  }

  public double getLeftVelocityInInchesPerSecond() {
    double leftVelocityInRotationsPerMinute = -mLeftEncoder.getVelocity();
    double leftVelocityInRotationsPerSecond = leftVelocityInRotationsPerMinute / 60.0;
    return UnitConversion.convertRotationsToInches(leftVelocityInRotationsPerSecond / kGearRatio, kWheelDiameter); 
  }

  public double getLeftAccelerationInInchesPerSecondSquared() {
    return mLeftAccelerationTracker.getDerivative();
  }

  public double getRightPositionInInches() {
    double rightPositionInRotations = mRightEncoder.getPosition();
    return UnitConversion.convertRotationsToInches(rightPositionInRotations / kGearRatio, kWheelDiameter);
  }

  public double getRightVelocityInInchesPerSecond() {
    double rightVelocityInRotationsPerMinute = mRightEncoder.getVelocity();
    double rightVelocityInRotationsPerSecond = rightVelocityInRotationsPerMinute / 60.0;
    return UnitConversion.convertRotationsToInches(rightVelocityInRotationsPerSecond / kGearRatio, kWheelDiameter); 
  }

  public double getRightAccelerationInInchesPerSecondSquared() {
    return mRightAccelerationTracker.getDerivative();
  }

  public void updateKinematics(double currentTime) {
    mLeftAccelerationTracker.update(getLeftVelocityInInchesPerSecond(), currentTime);
    mRightAccelerationTracker.update(getRightVelocityInInchesPerSecond(), currentTime);
  }

}
